<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Home;
use Illuminate\Http\Request;

class AppController extends Controller
{
  public function home()
  {
    $dataHome = Home::latest()->get();
    return view(
      'client/pages/homepage',
      [
        'dataHome' => $dataHome
      ]
    );
  }
  public function about()
  {
    $dataHome = Home::latest()->get();
    return view(
      'client/pages/aboutpage',
      [
        'dataHome' => $dataHome
      ]
    );
  }
  public function services()
  {
    $dataHome = Home::latest()->get();
    return view(
      'client/pages/servicespage',
      [
        'dataHome' => $dataHome
      ]
    );
  }
  public function product()
  {
    $dataHome = Home::latest()->get();
    return view(
      'client/pages/productpage',
      [
        'dataHome' => $dataHome
      ]
    );
  }
  public function project()
  {
    $dataHome = Home::latest()->get();
    return view(
      'client/pages/projectpage',
      [
        'dataHome' => $dataHome
      ]
    );
  }
  public function contact()
  {
    $dataHome = Home::latest()->get();
    return view(
      'client/pages/contactpage',
      [
        'dataHome' => $dataHome
      ]
    );
  }
}
