<div class="py-6 px-6 text-center">
  <p class="mb-0 fs-4">Design and Developed by <a href="#" class="pe-1 text-primary text-decoration-underline"></a>
    <a href="https://technoart.id/" target="_blank">Technart.id</a>
  </p>
</div>
