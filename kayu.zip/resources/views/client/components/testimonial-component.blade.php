<div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
  <div class="container">
    <div class="section-title text-center">
      <h1 class="display-5 mb-5">Testimonial</h1>
    </div>
    <div class="owl-carousel testimonial-carousel">
      <div class="testimonial-item text-center">
        <img class="img-fluid bg-light p-2 mx-auto mb-3" src="{{ asset('assets_client/img/testimonial-1.jpg') }}"
          style="width: 90px; height: 90px;">
        <div class="testimonial-text text-center p-4">
          <p>Clita clita tempor justo dolor ipsum amet kasd amet duo justo duo duo labore sed sed. Magna ut diam sit
            et amet stet eos sed clita erat magna elitr erat sit sit erat at rebum justo sea clita.</p>
          <h5 class="mb-1">Client Name</h5>
          <span class="fst-italic">Profession</span>
        </div>
      </div>
      <div class="testimonial-item text-center">
        <img class="img-fluid bg-light p-2 mx-auto mb-3" src="{{ asset('assets_client/img/testimonial-2.jpg') }}"
          style="width: 90px; height: 90px;">
        <div class="testimonial-text text-center p-4">
          <p>Clita clita tempor justo dolor ipsum amet kasd amet duo justo duo duo labore sed sed. Magna ut diam sit
            et amet stet eos sed clita erat magna elitr erat sit sit erat at rebum justo sea clita.</p>
          <h5 class="mb-1">Client Name</h5>
          <span class="fst-italic">Profession</span>
        </div>
      </div>
      <div class="testimonial-item text-center">
        <img class="img-fluid bg-light p-2 mx-auto mb-3" src="{{ asset('assets_client/img/testimonial-3.jpg') }}"
          style="width: 90px; height: 90px;">
        <div class="testimonial-text text-center p-4">
          <p>Clita clita tempor justo dolor ipsum amet kasd amet duo justo duo duo labore sed sed. Magna ut diam sit
            et amet stet eos sed clita erat magna elitr erat sit sit erat at rebum justo sea clita.</p>
          <h5 class="mb-1">Client Name</h5>
          <span class="fst-italic">Profession</span>
        </div>
      </div>
    </div>
  </div>
</div>
