<?php

use App\Http\Controllers\Client\AppController;
use App\Http\Controllers\Client\AuthController;
use App\Http\Controllers\Server\DashboardController;
use App\Http\Controllers\Server\HomeController;
use Illuminate\Support\Facades\Route;


// client
Route::get('/', [AppController::class, 'home'])->name('homepage');
Route::get('/about', [AppController::class, 'about'])->name('aboutpage');
Route::get('/services', [AppController::class, 'services'])->name('servicespage');
Route::get('/project', [AppController::class, 'project'])->name('projectpage');
Route::get('/product', [AppController::class, 'product'])->name('productpage');
Route::get('/contact', [AppController::class, 'contact'])->name('contactpage');


// auth
Route::get('/login', [AuthController::class, 'login']);


// server
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

Route::get('/admin/home', [HomeController::class, 'index'])->name('index.home');
Route::get('/admin/home/create', [HomeController::class, 'create'])->name('create.home');
Route::get('/admin/home/{id}/edit', [HomeController::class, 'edit'])->name('edit.home');
Route::post('/admin/home/store', [HomeController::class, 'store'])->name('store.home');
Route::delete('/admin/home/{id}', [HomeController::class, 'destroy'])->name('delete.home');
