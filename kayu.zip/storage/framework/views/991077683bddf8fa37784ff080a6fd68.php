<?php $__env->startSection('content-client'); ?>
  <!-- Page Header Start -->
  <div class="container-fluid page-header py-5 mb-5">
    <div class="container py-5">
      <h1 class="display-3 text-white mb-3 animated slideInDown">About Us</h1>
      <nav aria-label="breadcrumb animated slideInDown">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
          <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
          <li class="breadcrumb-item text-white active" aria-current="page">About</li>
        </ol>
      </nav>
    </div>
  </div>
  <!-- Page Header End -->

  <!-- About Start -->
  <div class="container-fluid bg-light overflow-hidden my-5 px-lg-0">
    <div class="container about px-lg-0">
      <div class="row g-0 mx-lg-0">
        <div class="col-lg-6 ps-lg-0" style="min-height: 400px;">
          <div class="position-relative h-100">
            <img class="position-absolute img-fluid w-100 h-100" src="<?php echo e(asset('assets_client/img/about.jpg')); ?>"
              style="object-fit: cover;" alt="">
          </div>
        </div>
        <div class="col-lg-6 about-text py-5 wow fadeIn" data-wow-delay="0.5s">
          <div class="p-lg-5 pe-lg-0">
            <div class="section-title text-start">
              <h1 class="display-5 mb-4">About Us</h1>
            </div>
            <p class="mb-4 pb-2">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et
              eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo erat amet</p>
            <div class="row g-4 mb-4 pb-2">
              <div class="col-sm-6 wow fadeIn" data-wow-delay="0.1s">
                <div class="d-flex align-items-center">
                  <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-white"
                    style="width: 60px; height: 60px;">
                    <i class="fa fa-users fa-2x text-primary"></i>
                  </div>
                  <div class="ms-3">
                    <h2 class="text-primary mb-1" data-toggle="counter-up">1234</h2>
                    <p class="fw-medium mb-0">Happy Clients</p>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 wow fadeIn" data-wow-delay="0.3s">
                <div class="d-flex align-items-center">
                  <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-white"
                    style="width: 60px; height: 60px;">
                    <i class="fa fa-check fa-2x text-primary"></i>
                  </div>
                  <div class="ms-3">
                    <h2 class="text-primary mb-1" data-toggle="counter-up">1234</h2>
                    <p class="fw-medium mb-0">Projects Done</p>
                  </div>
                </div>
              </div>
            </div>
            <a href="" class="btn btn-primary py-3 px-5">Explore More</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- About End -->

  <!-- Team Start -->
  <div class="container-xxl py-5">
    <div class="container">
      <div class="section-title text-center">
        <h1 class="display-5 mb-5">Team Members</h1>
      </div>
      <div class="row g-4">
        <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
          <div class="team-item">
            <div class="overflow-hidden position-relative">
              <img class="img-fluid" src="<?php echo e(asset('assets_client/img/team-1.jpg')); ?>" alt="">
              <div class="team-social">
                <a class="btn btn-square" href=""><i class="fab fa-facebook-f"></i></a>
                <a class="btn btn-square" href=""><i class="fab fa-twitter"></i></a>
                <a class="btn btn-square" href=""><i class="fab fa-instagram"></i></a>
              </div>
            </div>
            <div class="text-center border border-5 border-light border-top-0 p-4">
              <h5 class="mb-0">Full Name</h5>
              <small>Designation</small>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
          <div class="team-item">
            <div class="overflow-hidden position-relative">
              <img class="img-fluid" src="<?php echo e(asset('assets_client/img/team-2.jpg')); ?>" alt="">
              <div class="team-social">
                <a class="btn btn-square" href=""><i class="fab fa-facebook-f"></i></a>
                <a class="btn btn-square" href=""><i class="fab fa-twitter"></i></a>
                <a class="btn btn-square" href=""><i class="fab fa-instagram"></i></a>
              </div>
            </div>
            <div class="text-center border border-5 border-light border-top-0 p-4">
              <h5 class="mb-0">Full Name</h5>
              <small>Designation</small>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
          <div class="team-item">
            <div class="overflow-hidden position-relative">
              <img class="img-fluid" src="<?php echo e(asset('assets_client/img/team-3.jpg')); ?>" alt="">
              <div class="team-social">
                <a class="btn btn-square" href=""><i class="fab fa-facebook-f"></i></a>
                <a class="btn btn-square" href=""><i class="fab fa-twitter"></i></a>
                <a class="btn btn-square" href=""><i class="fab fa-instagram"></i></a>
              </div>
            </div>
            <div class="text-center border border-5 border-light border-top-0 p-4">
              <h5 class="mb-0">Full Name</h5>
              <small>Designation</small>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
          <div class="team-item">
            <div class="overflow-hidden position-relative">
              <img class="img-fluid" src="<?php echo e(asset('assets_client/img/team-4.jpg')); ?>" alt="">
              <div class="team-social">
                <a class="btn btn-square" href=""><i class="fab fa-facebook-f"></i></a>
                <a class="btn btn-square" href=""><i class="fab fa-twitter"></i></a>
                <a class="btn btn-square" href=""><i class="fab fa-instagram"></i></a>
              </div>
            </div>
            <div class="text-center border border-5 border-light border-top-0 p-4">
              <h5 class="mb-0">Full Name</h5>
              <small>Designation</small>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Team End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Web\simkatmuh\resources\views/client/about.blade.php ENDPATH**/ ?>