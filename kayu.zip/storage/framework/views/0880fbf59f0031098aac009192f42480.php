<?php $__env->startSection('content-client'); ?>
  <!-- Carousel Start -->
  <div class="container-fluid p-0 pb-5">
    <div class="owl-carousel header-carousel position-relative">

      <?php $__currentLoopData = $dataHome; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="owl-carousel-item position-relative">
          <img class="img-fluid" src="<?php echo e(asset('img/' . $item->img ?? '')); ?>" alt=""
            style="object-fit: cover; height: 500px;">
          <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center"
            style="background: rgba(53, 53, 53, .7);">
            <div class="container">
              <div class="row justify-content-center">
                <div class="col-12 col-lg-8 text-center">
                  <h5 class="text-white text-uppercase mb-3 animated slideInDown"><?php echo e($item->slogan); ?></h5>
                  <h1 class="display-3 text-white animated slideInDown mb-4"><?php echo e($item->judul); ?></h1>
                  <p class="fs-5 fw-medium text-white mb-4 pb-2"><?php echo e($item->deskripsi); ?></p>
                  <a href="" class="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">Read More</a>
                  <a href="" class="btn btn-light py-md-3 px-md-5 animated slideInRight">Free Quote</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>
  <!-- Carousel End -->


  <!-- Feature Start -->
  <?php echo $__env->make('client.components.future-component', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Feature Start -->



  <!-- About Start -->
  <?php echo $__env->make('client.components.about-component', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- About End -->


  <!-- Service Start -->
  <?php echo $__env->make('client.components.services-component', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Service End -->


  <!-- Feature Start -->
  <?php echo $__env->make('client.components.future-component', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Feature End -->


  <!-- Projects Start -->
  <?php echo $__env->make('client.components.project-component', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Projects End -->


  <!-- Quote Start -->
  <?php echo $__env->make('client.components.quote-component', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Quote End -->


  <!-- Team Start -->
  <?php echo $__env->make('client.components.team-component', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Team End -->


  <!-- Testimonial Start -->
  <?php echo $__env->make('client.components.testimonial-component', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Testimonial End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Web\simkatmuh\resources\views/client/pages/homepage.blade.php ENDPATH**/ ?>