<?php $__env->startSection('content-client'); ?>
  <!-- Page Header Start -->
  <div class="container-fluid page-header py-5 mb-5">
    <div class="container py-5">
      <h1 class="display-3 text-white mb-3 animated slideInDown">About Us</h1>
      <nav aria-label="breadcrumb animated slideInDown">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
          <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
          <li class="breadcrumb-item text-white active" aria-current="page">About</li>
        </ol>
      </nav>
    </div>
  </div>
  <!-- Page Header End -->

  <!-- About Start -->
  <?php echo $__env->make('client.components.about-component', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- About End -->

  <!-- Team Start -->
  <?php echo $__env->make('client.components.team-component', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Team End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Web\simkatmuh\resources\views/client/pages/aboutpage.blade.php ENDPATH**/ ?>